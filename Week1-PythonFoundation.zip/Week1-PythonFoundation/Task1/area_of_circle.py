import math

radius = float(input("Enter the radius of the circle: "))
area = math.pi * radius ** 2

print("Area of the circle:", area)
