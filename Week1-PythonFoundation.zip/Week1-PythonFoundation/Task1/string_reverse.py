text = input("Enter a string: ")
reversed_text = text[::-1]

print("Reversed string:", reversed_text)
