# Task 1 — Python Basics & Git

## What I Learned
- Difference between AI, ML, DL, and Data Science
- Python fundamentals (variables, loops, conditionals)
- Writing basic Python programs
- Git and GitHub workflow

## How to Run
Navigate to the Task1 directory and run:
python filename.py


python factorial.py
