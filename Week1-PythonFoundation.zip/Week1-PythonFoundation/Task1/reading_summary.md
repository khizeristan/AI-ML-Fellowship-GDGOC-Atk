Artificial Intelligence (AI) is the broad field focused on building intelligent machines.
Machine Learning (ML) is a subset of AI that enables systems to learn from data.
Deep Learning (DL) is a part of ML that uses multi-layer neural networks.
Data Science focuses on extracting insights from structured and unstructured data.
AI emphasizes decision-making, while Data Science emphasizes analysis.
ML and DL act as the learning engines behind AI systems.

