from setuptools import setup, find_packages

setup(
    name="mypackage",
    version="1.0.0",
    packages=find_packages(),
    description="Custom Python package for Task 4",
    author="Hizar Abdullah",
)