from calculator import add, subtract
from utils import greet

print(add(5, 3))           # 8
print(subtract(10, 4))     # 6
print(greet("Hizar"))      # Hello, Hizar!