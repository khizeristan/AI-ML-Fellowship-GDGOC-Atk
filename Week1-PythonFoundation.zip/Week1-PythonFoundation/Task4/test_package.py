from mypackage import multiply, shout, log_info

print(multiply(5, 4))   # 20
print(shout("hello"))   # HELLO
log_info("Task 4 is running perfectly!")
