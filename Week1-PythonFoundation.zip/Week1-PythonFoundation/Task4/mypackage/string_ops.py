def capitalize_text(text):
    return text.capitalize()

def shout(text):
    return text.upper()