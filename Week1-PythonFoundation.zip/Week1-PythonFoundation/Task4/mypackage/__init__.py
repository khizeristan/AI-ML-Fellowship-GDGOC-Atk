from .math_ops import multiply, divide
from .string_ops import capitalize_text, shout
from .logger import log_info, log_error